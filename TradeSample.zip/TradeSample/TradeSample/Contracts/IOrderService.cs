﻿using System.Collections.Generic;
using TradeSample.Models;
namespace TradeSample.Contracts
{
    /// <summary>
    /// Order Service Contract.
    /// </summary>
    public interface IOrderService
    {
        /// <summary>
        /// Load Orders from Csv file.
        /// </summary>
        /// <param name="orderCount">order count</param>
        /// <param name="isValidHeader">isValidHeader determines whether the csv file has valid template or not</param>
        /// <returns>Orders loaded from csv file.</returns>
        IList<Order> LoadOrdersFromFile(int orderCountout, out bool isValidHeader);
        
        /// <summary>
        /// Exports to csv
        /// </summary>
        /// <param name="orders">Orders to export</param>
        /// <param name="isTemplateExport">isTemplateExport determines template export or order export</param>
        void Export(IEnumerable<Order> orders, bool isTemplateExport);

        /// <summary>
        /// Submit Orders to Exchange.
        /// </summary>
        /// <param name="orders">Orders which will be sent to exchange</param>
        void SubmitOrders(IEnumerable<Order> orders);

        /// <summary>
        /// Validate Orders and change status for validation succeeded orders.
        /// </summary>
        /// <param name="orders">Orders for validation</param>
        void ValidateOrdersAndChangeStatus(IEnumerable<Order> orders);
    }
}
