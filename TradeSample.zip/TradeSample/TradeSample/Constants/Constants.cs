﻿namespace TradeSample.Constants
{
    /// <summary>
    /// Constants
    /// </summary>
    public class Constants
    {
        public const int MAX_LOT_SIZE = 100000;
    }
}
