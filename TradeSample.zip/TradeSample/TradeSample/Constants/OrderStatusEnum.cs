﻿using System;
namespace TradeSample.Constants
{
    /// <summary>
    /// Order Status
    /// </summary>
    public enum OrderStatus
    {
        NotAssigned = 0,
        New,
        Submitted,
        Approved,
        Rejected
    }
}
