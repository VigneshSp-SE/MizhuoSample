﻿using System.Windows;
using TradeSample.ViewModels;

namespace TradeSample
{
    /// <summary>
    /// Interaction logic for OrderView.xaml
    /// </summary>
    public partial class OrderView : Window
    {
        private OrderViewModel _viewModel;
        public OrderView()
        {
            InitializeComponent();
            _viewModel = new OrderViewModel();
            SetDataContext();
        }

        /// <summary>
        /// Sets DataContext for Order View.
        /// </summary>
        private void SetDataContext() => DataContext = _viewModel;

    }
}
