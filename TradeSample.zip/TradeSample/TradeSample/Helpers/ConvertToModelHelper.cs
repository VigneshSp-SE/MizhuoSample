﻿using System;
using System.Linq;
using System.Reflection;
using TradeSample.Attributes;
using TradeSample.Constants;
using TradeSample.Models;

namespace TradeSample.Helpers
{
    /// <summary>
    /// Convert To Model Helper.
    /// </summary>
    public class ConvertToModelHelper
    {
        /// <summary>
        /// Converts Csv String To Model.
        /// </summary>
        /// <typeparam name="T">Model Type</typeparam>
        /// <param name="csvLine">Csv Line to get converted</param>
        /// <param name="orderCount">orderCount for order ID</param>
        /// <returns>Object of required type with csv file values.</returns>
        public static T ConvertCsvStringToModel<T>(string csvLine, int orderCount)
        {
            decimal price;
            int quantity;
            var index = 0;
            Type itemType = typeof(T);
            var obj = Activator.CreateInstance(typeof(T));
            var props = itemType.GetProperties(BindingFlags.Public | BindingFlags.Instance).Where(prop => prop.IsDefined(typeof(CsvRequiredAttribute)));
            string[] values = csvLine.Split(',');
            
            foreach (var property in props)
            {
                var value = values[index].Trim();
                System.TypeCode typeCode = Type.GetTypeCode(property.PropertyType);
                switch (typeCode)
                {
                    case TypeCode.Decimal:
                        var decimalValue =  Decimal.TryParse(value, out price) ? price : default;
                        property.SetValue(obj, decimalValue);
                        break;
                    case TypeCode.Int32:
                        var intValue = Int32.TryParse(value, out quantity) ? quantity : default;
                        property.SetValue(obj, intValue);
                        break;
                    default:
                        property.SetValue(obj, value); 
                        break;
                }
                index++;
            }

            if(obj is Order)
            {
                // Sets Order ID and Order Status.
                var orderId = obj.GetType().GetProperty(nameof(Order.ID)); 
                var orderStatus = obj.GetType().GetProperty(nameof(Order.Status));
                orderId.SetValue(obj, orderCount);
                orderStatus.SetValue(obj, OrderStatus.New);
            }
            return (T)obj;
        }
    }
}
