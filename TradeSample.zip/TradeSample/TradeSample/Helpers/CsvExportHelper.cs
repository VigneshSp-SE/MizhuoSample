﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using TradeSample.Attributes;

namespace TradeSample.Helpers
{
    /// <summary>
    /// Csv Export Helper Class.
    /// </summary>
    public class CsvExportHelper
    {
        /// <summary>
        /// Save File.
        /// </summary>
        /// <typeparam name="T">Type of object to write in csv file</typeparam>
        /// <param name="items">Collection of object to write into csv file</param>
        /// <param name="isTemplateExport">isTemplateExport determines to export csv template or collection of object</param>
        public static void SaveFile<T>(IEnumerable<T> items, bool isTemplateExport)
        {
            // Displays a SaveFileDialog.
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "csv files (*.csv)|*.csv";
            saveFileDialog.Title = "Save as CSV File";
            saveFileDialog.ShowDialog();

            var filePath = saveFileDialog.FileName;

            if (string.IsNullOrEmpty(filePath) == false)
                WriteToCSV(items, filePath, isTemplateExport);
        }

        /// <summary>
        /// Writes To Csv file.
        /// </summary>
        /// <typeparam name="T">Type of object to write in csv file</typeparam>
        /// <param name="items">Collection of object to write into csv file</param>
        /// <param name="path">Output file path</param>
        /// <param name="isTemplateExport">isTemplateExport determines to export csv template or collection of object</param>
        private static void WriteToCSV<T>(IEnumerable<T> items, string path, bool isTemplateExport)
        {
            Type itemType = typeof(T);
            var props = itemType.GetProperties(BindingFlags.Public | BindingFlags.Instance).Where(prop => prop.IsDefined(typeof(CsvRequiredAttribute)));
            Encoding streamEncoding = Encoding.Default;
            var isAppend = false;
            using (var writer = new StreamWriter(path, isAppend, streamEncoding))
            {
                writer.WriteLine(string.Join(", ", props.Select(p => p.Name)));

                if (isTemplateExport == false)
                {
                    foreach (var item in items)
                    {
                        writer.WriteLine(string.Join(", ", props.Select(p => p.GetValue(item, null))));
                    }
                }
            }
        }
    }
}
