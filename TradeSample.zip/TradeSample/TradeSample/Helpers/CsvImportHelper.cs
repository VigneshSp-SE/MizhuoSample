﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using TradeSample.Attributes;
using TradeSample.Models;

namespace TradeSample.Helpers
{
    /// <summary>
    /// Csv Import Helper Class.
    /// </summary>
    public class CsvImportHelper
    {
        /// <summary>
        /// Reads From Csv File.
        /// </summary>
        /// <param name="orderCount">Order count</param>
        /// <param name="isValidHeader">isValidHeader determines whether the csv file has valid template or not</param>
        /// <returns>collection of object from csv file</returns>
        public static IList<T> ReadFromFile<T>(int orderCount, out bool isValidHeader)
        {
            var orders = new List<T>();
            isValidHeader = true;
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.Filter = "csv files (*.csv)|*.csv";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    var fileStream = openFileDialog.OpenFile();
                    ReadFromCsv(orderCount, fileStream, orders, out isValidHeader);
                }
            }
            return orders;
        }

        /// <summary>
        /// Reads from csv file
        /// </summary>
        /// <param name="orderCount">order count</param>
        /// <param name="fileStream">filestream of the opened file</param>
        /// <param name="items">Collection of object read from csv file</param>
        /// <param name="isValidHeader">isValidHeader determines whether the csv file has valid template or not</param>
        private static void ReadFromCsv<T>(int orderCount, Stream fileStream, List<T> items, out bool isValidHeader)
        {
            //Read the contents of the file into a stream
            Encoding streamEncoding = Encoding.Default;
            var enc = Encoding.GetEncoding(932);
            using (StreamReader reader = new StreamReader(fileStream, enc))
            {
                var headerline = reader.ReadLine();
                isValidHeader = CheckValidHeaderTemplate<Order>(headerline);
                if (isValidHeader)
                    while (!reader.EndOfStream)
                    {
                        orderCount++;
                        var line = reader.ReadLine();
                        items.Add(ConvertToModelHelper.ConvertCsvStringToModel<T>(line, orderCount));
                    }
            }
        }

        /// <summary>
        /// Checks Csv file's Header Template
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="headerline"></param>
        /// <returns>If valid template, then returns true otherwise false</returns>
        private static bool CheckValidHeaderTemplate<T>(string headerline)
        {
            Type itemType = typeof(T);
            var csvHeaders = headerline.Split(',').Select(p => p.Trim()).ToList();
            var mandatoryColumnHeaders = itemType.GetProperties(BindingFlags.Public | BindingFlags.Instance).Where(prop => prop.IsDefined(typeof(CsvRequiredAttribute))).Select(prop => prop.Name);
            return csvHeaders.SequenceEqual(mandatoryColumnHeaders);
        }
    }
}
