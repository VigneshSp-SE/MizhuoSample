﻿using System;
namespace TradeSample.Attributes
{
    /// <summary>
    /// Attribute that indicates a property is required for Csv Import/Export.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class CsvRequiredAttribute : Attribute
    {
    }
}
