﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;

namespace TradeSample.ViewModels
{
    /// <summary>
    /// Validation Base Class for Data Validation.
    /// </summary>
    public class ValidationBase : BindableBase, INotifyDataErrorInfo
    {

        protected readonly Dictionary<string, ICollection<string>> _validationErrors = new Dictionary<string, ICollection<string>>();

        #region INotifyDataErrorInfo members
        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;

        /// <summary>
        /// Raise Errors Changed.
        /// </summary>
        /// <param name="propertyName">name of property</param>
        protected void RaiseErrorsChanged(string propertyName)
        {
            if (ErrorsChanged != null)
                ErrorsChanged(this, new DataErrorsChangedEventArgs(propertyName));
        }

        /// <summary>
        /// GetErrors
        /// </summary>
        /// <param name="propertyName">name of property</param>
        /// <returns>Collection of validation errors</returns>
        public IEnumerable GetErrors(string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName)
                || !_validationErrors.ContainsKey(propertyName))
                return null;

            return _validationErrors[propertyName];
        }

        /// <summary>
        /// Checks for validation errors.
        /// </summary>
        public bool HasErrors
        {
            get { return _validationErrors.Count > 0; }
        }
        #endregion
    }
}
