﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Input;
using TradeSample.Behaviors;
using TradeSample.Contracts;
using TradeSample.Models;
using TradeSample.Properties;

namespace TradeSample.ViewModels
{
    /// <summary>
    /// Order ViewModel.
    /// </summary>
    public class OrderViewModel
    {
        #region Private Fields
        private IOrderService _model;
        private ICommand _loadCommand;
        private ICommand _exportCommand;
        private ICommand _submitCommand;
        private ICommand _deleteAllCommand;
        private ICommand _deleteCommand;
        #endregion

        #region Binding Properties

        /// <summary>
        /// Orders
        /// </summary>
        public ObservableCollection<Order> Orders { get; set; }

        /// <summary>
        /// Load Orders Command
        /// </summary>
        public ICommand LoadCommand
        {
            get
            {
                if (_loadCommand == null)
                {
                    _loadCommand = new RelayCommand(param => LoadOrdersFromFile());
                }
                return _loadCommand;
            }
        }

        /// <summary>
        /// Export Orders Command
        /// </summary>
        public ICommand ExportCommand
        {
            get
            {
                if (_exportCommand == null)
                {
                    _exportCommand = new RelayCommand(param => Export(param));
                }
                return _exportCommand;
            }
        }

        /// <summary>
        /// Submit Orders Command
        /// </summary>
        public ICommand SubmitCommand
        {
            get
            {
                if (_submitCommand == null)
                {
                    _submitCommand = new RelayCommand(param => SubmitOrders(param));
                }
                return _submitCommand;
            }
        }

        /// <summary>
        /// Delete All Orders Command
        /// </summary>
        public ICommand DeleteAllCommand
        {
            get
            {
                if (_deleteAllCommand == null)
                {
                    _deleteAllCommand = new RelayCommand(param => Orders.Clear());
                }
                return _deleteAllCommand;
            }
        }

        /// <summary>
        /// Delete Order Command
        /// </summary>
        public ICommand DeleteCommand
        {
            get
            {
                if (_deleteCommand == null)
                {
                    _deleteCommand = new RelayCommand(param => DeleteOrder(param));
                }
                return _deleteCommand;
            }
        }

        /// <summary>
        /// Load Csv Button Content
        /// </summary>
        public string LoadCsvContent { get; } = Resources.LoadCsv;

        /// <summary>
        /// Export Template Button Content
        /// </summary>
        public string ExportTemplateContent { get; } = Resources.ExportCsvTemplateContent;

        /// <summary>
        /// Export Csv Button Content
        /// </summary>
        public string ExportCsvContent { get; } = Resources.ExportCsvContent;

        /// <summary>
        /// Delete All Button Content
        /// </summary>
        public string DeleteAllContent { get; } = Resources.DeleteAllContent;

        /// <summary>
        /// Submit Button Content
        /// </summary>
        public string SubmitContent { get; } = Resources.SubmitContent;

        /// <summary>
        /// Order Status Tool Tip Text for legends.
        /// </summary>
        public string OrderStatus { get; } = nameof(Constants.OrderStatus);

        /// <summary>
        /// New Status for legends
        /// </summary>
        public string NewOrderStatus { get; } = nameof(Constants.OrderStatus.New);

        /// <summary>
        /// Submitted Status for legends
        /// </summary>
        public string SubmittedOrderStatus { get; } = nameof(Constants.OrderStatus.Submitted);

        /// <summary>
        /// Approved Status for legends
        /// </summary>
        public string ApprovedOrderStatus { get; } = nameof(Constants.OrderStatus.Approved);

        /// <summary>
        /// Rejected Status for legends
        /// </summary>
        public string RejectedOrderStatus { get; } = nameof(Constants.OrderStatus.Rejected);
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor to Initailize.
        /// </summary>
        public OrderViewModel()
        {
            _model = new OrderModel();
            Orders = new ObservableCollection<Order>();
        }
        #endregion

        #region Private Members
        /// <summary>
        /// Load Orders From Csv file.
        /// </summary>
        private void LoadOrdersFromFile()
        {
            try
            {
                bool isvalidHeader;
                var orderID = Orders.Count > 0 ? Orders.Select(order => order.ID).Max() : 0;
                var importedOrders = _model.LoadOrdersFromFile(orderID, out isvalidHeader);

                if (isvalidHeader == false)
                {
                    System.Windows.Forms.MessageBox.Show(ErrorMessageResources.InvalidTemplate, ErrorMessageResources.LoadFailed, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                importedOrders.ToList().ForEach(Orders.Add);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message, ErrorMessageResources.LoadFailed, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Delete Order
        /// </summary>
        /// <param name="param">order ID to delete</param>
        private void DeleteOrder(object param)
        {
            var orderId = (int)param;
            var orderToDelete = Orders.First(order => order.ID == orderId);
            Orders.Remove(orderToDelete);
        }

        /// <summary>
        /// Submit Orders to Exchange.
        /// </summary>
        /// <param name="param"></param>
        private void SubmitOrders(object param)
        {
            _model.ValidateOrdersAndChangeStatus(Orders);
            _model.SubmitOrders(Orders);
        }

        /// <summary>
        /// Export to csv file.
        /// </summary>
        /// <param name="param">Template Export flag (True -> exports template or False -> exports Orders)</param>
        private void Export(object param)
        {
            try
            {
                var isTemplateExport = Convert.ToBoolean(param);
                _model.Export(Orders, isTemplateExport);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message, ErrorMessageResources.ExportFailed, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion
    }
}
