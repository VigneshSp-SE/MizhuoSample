﻿using System.Windows;
using System.Windows.Threading;

namespace TradeSample
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        /// <summary>
        /// Application Dispatcher Unhandled Exception.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Application_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            MessageBox.Show(string.Format(TradeSample.Properties.ErrorMessageResources.UnExpected, e.Exception), TradeSample.Properties.ErrorMessageResources.UnexpectedTitle, MessageBoxButton.OK, MessageBoxImage.Error);
            Current.Shutdown();
        }
    }
}
