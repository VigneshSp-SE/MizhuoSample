﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TradeSample.Constants;
using TradeSample.Contracts;
using TradeSample.Helpers;
using TradeSample.Properties;

namespace TradeSample.Models
{
    /// <summary>
    /// Order Model.
    /// </summary>
    public class OrderModel : IOrderService
    {
        /// <summary>
        /// Load Orders from Csv file.
        /// </summary>
        /// <param name="orderCount">order count</param>
        /// <param name="isValidHeader">isValidHeader determines whether the csv file has valid template or not</param>
        /// <returns>Orders loaded from csv file.</returns>
        public IList<Order> LoadOrdersFromFile(int orderCount, out bool isValidHeader)
        {
            return CsvImportHelper.ReadFromFile<Order>(orderCount, out isValidHeader);
        }

        /// <summary>
        /// Exports to csv
        /// </summary>
        /// <param name="orders">Orders to export</param>
        /// <param name="isTemplateExport">isTemplateExport determines template export or order export</param>
        public void Export(IEnumerable<Order> orders, bool isTemplateExport)
        {
            CsvExportHelper.SaveFile(orders, isTemplateExport);
        }

        /// <summary>
        /// Submit Orders to Exchange (Mock Exchange Result to update orders).
        /// </summary>
        /// <param name="orders">Orders which will be sent to exchange</param>
        public void SubmitOrders(IEnumerable<Order> orders)
        {
            var ordersToSubmit = orders.Where(order => order.IsWaitingForSubmit);

            foreach (var order in ordersToSubmit)
                order.IsWaitingForSubmit = false;

            // Mock Exchange Result to update orders.
            Task.Run(() =>
            {
                // send Orders to Exchange (ordersToSubmit).
                Thread.Sleep(5000);
            }).ContinueWith((t) =>
            {
                // Mock result
                var orderToUpdate = orders.Where(order => order.Status == OrderStatus.Submitted);
                ChangeOrderStatus(orderToUpdate.Where(order => order.ID % 2 == 0), OrderStatus.Approved);
                ChangeOrderStatus(orderToUpdate.Where(order => order.ID % 5 == 0), OrderStatus.Rejected);
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        /// <summary>
        /// Validate Orders and change status for validation succeeded orders.
        /// </summary>
        /// <param name="orders">Orders for validation</param>
        public void ValidateOrdersAndChangeStatus(IEnumerable<Order> orders)
        {
            var ordersToSubmit = orders.Where(order => order.Status == OrderStatus.New);

            //Normalize InstrumentCode and get the total Quantity allocated for an instrument.
            var instrumentsWithLotSize = ordersToSubmit.Select(order => new { InstrumentCode = order.InstrumentCode.Normalize(NormalizationForm.FormKC), order.Quantity })
                .GroupBy(order => new { order.InstrumentCode }).Select(group => new KeyValuePair<string, int>(group.Key.InstrumentCode, group.Sum(x => x.Quantity)));

            foreach (var order in ordersToSubmit)
            {
                var isValid = true;
                isValid &= IsValidQuantity(order) && IsValidLotSize(order, instrumentsWithLotSize);
                isValid &= IsValidPrice(order);

                if (isValid)
                {
                    order.IsWaitingForSubmit = true;
                    order.Status = OrderStatus.Submitted;
                }
            }
        }

        /// <summary>
        /// Checks whether the order has valid Price or not.
        /// </summary>
        /// <param name="order">order to validate</param>
        /// <returns>valid status</returns>
        /// <remarks>If not valid then adds error message to property, otherwise removes error message if exists</remarks>
        private bool IsValidPrice(Order order)
        {
            var IsValid = true;
            if (order.Price <= 0)
            {
                IsValid = false;
                order.AddValidationError(nameof(Order.Price), string.Format(ErrorMessageResources.InvalidPriceRange));
            }
            else
                order.RemoveValidationError(nameof(Order.Price));

            return IsValid;
        }

        /// <summary>
        /// Checks whether the order has valid Quantity or not.
        /// </summary>
        /// <param name="order">order to validate</param>
        /// <returns>valid status</returns>
        /// <remarks>If not valid then adds error message to property, otherwise removes error message if exists</remarks>
        private bool IsValidQuantity(Order order)
        {
            var IsValid = true;
            if (order.Quantity <= 0)
            {
                IsValid = false;
                order.AddValidationError(nameof(Order.Quantity), string.Format(ErrorMessageResources.InvalidQuantityRange));
            }
            else
                order.RemoveValidationError(nameof(Order.Quantity));
            return IsValid;
        }

        /// <summary>
        /// Checks whether the Instrument has valid lot size or not.
        /// </summary>
        /// <param name="order">order to validate</param>
        /// <param name="instrumentsWithLotSize"></param>
        /// <returns>valid status</returns>
        /// <remarks>If not valid then adds error message to property, otherwise removes error message if exists</remarks>
        private bool IsValidLotSize(Order order, IEnumerable<KeyValuePair<string, int>> instrumentsWithLotSize)
        {
            var IsValid = true;
            var quantity = instrumentsWithLotSize.First(item => item.Key == order.InstrumentCode.Normalize(NormalizationForm.FormKC)).Value;
            if (quantity > Constants.Constants.MAX_LOT_SIZE)
            {
                IsValid = false;
                order.AddValidationError(nameof(Order.Quantity), string.Format(ErrorMessageResources.InvalidLotSize, order.InstrumentCode));
            }
            else
                order.RemoveValidationError(nameof(Order.Quantity));

            return IsValid;
        }

        /// <summary>
        /// Change Order Status.
        /// </summary>
        /// <param name="orders">Orders to change the status</param>
        /// <param name="status">Order Status to be changed</param>
        private void ChangeOrderStatus(IEnumerable<Order> orders, OrderStatus status)
        {
            foreach (var order in orders)
            {
                order.Status = status;
            }
        }
    }
}
