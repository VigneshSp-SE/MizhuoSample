﻿using System.Collections.Generic;
using TradeSample.Attributes;
using TradeSample.Constants;
using TradeSample.ViewModels;

namespace TradeSample.Models
{
    /// <summary>
    /// Order Model for Binding
    /// </summary>
    public class Order : ValidationBase
    {
        #region Private Fields
        private OrderStatus _orderStatus;
        #endregion

        #region Binding Properties
        /// <summary>
        /// Order ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Trading Account
        /// </summary>
        [CsvRequired]
        public string TradingAccount { get; set; }

        /// <summary>
        /// User ID
        /// </summary>
        [CsvRequired]
        public string UserId { get; set; }

        /// <summary>
        /// Instrument Code
        /// </summary>
        [CsvRequired]
        public string InstrumentCode { get; set; }

        /// <summary>
        /// Side
        /// </summary>
        [CsvRequired]
        public string Side { get; set; }

        /// <summary>
        /// Price
        /// </summary>
        [CsvRequired]
        public decimal Price { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        [CsvRequired]
        public int Quantity { get; set; }

        /// <summary>
        /// Order Status
        /// </summary>
        public OrderStatus Status
        {
            get
            {
                return _orderStatus;
            }
            set
            {
                _orderStatus = value;
                OnPropertyChanged(nameof(Status));
            }
        }

        /// <summary>
        /// Validation Errors.
        /// </summary>
        public Dictionary<string, ICollection<string>> ValidationErrors
        {
            get { return _validationErrors; }
        }

        /// <summary>
        /// Is order Submitted To Exchange.
        /// </summary>
        public bool IsWaitingForSubmit { get; set; }

        #endregion

        #region Validation Service Methods
        /// <summary>
        /// Adds ValidationError.
        /// </summary>
        /// <param name="propertyName">name of property</param>
        /// <param name="message">validation error message</param>
        public void AddValidationError(string propertyName, string message)
        {
            var existsInErrors = _validationErrors.ContainsKey(propertyName);
            if (existsInErrors)
                _validationErrors[propertyName].Add(message);
            else
                _validationErrors[propertyName] = new List<string> { message };
            RaiseErrorsChanged(propertyName);
        }

        /// <summary>
        /// Removes ValidationError.
        /// </summary>
        /// <param name="propertyName">name of property</param>
        public void RemoveValidationError(string propertyName)
        {
            var existsInErrors = _validationErrors.ContainsKey(propertyName);
            if (existsInErrors)
            {
                _validationErrors.Remove(propertyName);
                RaiseErrorsChanged(propertyName);
            }
        }
        #endregion
    }
}
