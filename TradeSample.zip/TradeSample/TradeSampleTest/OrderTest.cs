﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using TradeSample.Constants;
using TradeSample.Contracts;
using TradeSample.Models;

namespace TradeSampleTest
{
    [TestFixture]
    public class OrderTest
    {
        private IOrderService orderService;
        private List<Order> orders;
        private string invalidLotSizeErrorMessage;
        private string invalidPriceErrorMessage;
        private string invalidQuantityErrorMessage;
        private int validQuantity;
        private decimal validPrice;


        [SetUp]
        public void SetUp()
        {
            validQuantity = 1000;
            validPrice = 10000M;
            invalidLotSizeErrorMessage = "Invalid Lot size for {0}. Maximum allowed Lot size is 100,000.";
            invalidPriceErrorMessage = "Invalid Price. Enter Valid price more than 0.";
            invalidQuantityErrorMessage = "Invalid Quantity. Enter quantity more than 0.";
            orderService = new OrderModel();
            orders = new List<Order> { new Order { InstrumentCode = "E2000", Price = 10000M, Quantity = 100, Status = OrderStatus.New }, new Order { InstrumentCode = "E2001", Price = 2000.50M, Quantity = 10000, Status = OrderStatus.New } };
        }

        [TestCase(0)]
        [Test]
        public void ValidateOrdersAndChangeStatus_InvalidQuantity_HasError(int invalidQuantity)
        {
            //Arrange
            orders.Add(new Order { InstrumentCode = "E2001", Price = validPrice, Quantity = invalidQuantity, Status = OrderStatus.New });

            //Act
            orderService.ValidateOrdersAndChangeStatus(orders);
            var orderWithError = orders.Where(x => x.HasErrors);

            //Assert
            Assert.AreEqual(1, orderWithError.Count());
            Assert.AreEqual(invalidQuantity, orderWithError.First().Quantity);
            Assert.AreEqual(OrderStatus.New, orderWithError.First().Status);
            Assert.AreEqual(1, orderWithError.First().ValidationErrors.Count);
            Assert.AreEqual(invalidQuantityErrorMessage, orderWithError.First().ValidationErrors[nameof(Order.Quantity)].First());
        }

        [TestCase(100001)]
        [Test]
        public void ValidateOrdersAndChangeStatus_InvalidLotSize_OneOrderWithInstrumentHasError(int invalidLotSize)
        {
            //Arrange
            orders.Add(new Order { InstrumentCode = "E2002", Price = validPrice, Quantity = invalidLotSize, Status = OrderStatus.New });
            var expectedErrorMessage = string.Format(invalidLotSizeErrorMessage, "E2002");
            //Act
            orderService.ValidateOrdersAndChangeStatus(orders);
            var orderWithError = orders.Where(x => x.HasErrors);

            //Assert
            Assert.AreEqual(1, orderWithError.Count());
            Assert.AreEqual(OrderStatus.New, orderWithError.First().Status);
            Assert.AreEqual(1, orderWithError.First().ValidationErrors.Count);
            Assert.AreEqual(expectedErrorMessage, orderWithError.First().ValidationErrors[nameof(Order.Quantity)].First());
        }

        [TestCase(100001)]
        [Test]
        public void ValidateOrdersAndChangeStatus_InvalidLotSize_AllOrdersWithSameInstrumentHasError(int invalidLotSize)
        {
            //Arrange
            orders.Add(new Order { InstrumentCode = "E2001", Price = validPrice, Quantity = invalidLotSize, Status = OrderStatus.New });
            var expectedErrorMessage = string.Format(invalidLotSizeErrorMessage, "E2001");
            //Act
            orderService.ValidateOrdersAndChangeStatus(orders);
            var orderWithError = orders.Where(x => x.HasErrors);

            //Assert
            Assert.AreEqual(2, orderWithError.Count());
            Assert.AreEqual(OrderStatus.New, orderWithError.ElementAt(0).Status);
            Assert.AreEqual(OrderStatus.New, orderWithError.ElementAt(1).Status);
            Assert.AreEqual(1, orderWithError.ElementAt(0).ValidationErrors.Count);
            Assert.AreEqual(1, orderWithError.ElementAt(1).ValidationErrors.Count);
            Assert.AreEqual(expectedErrorMessage, orderWithError.ElementAt(0).ValidationErrors[nameof(Order.Quantity)].First());
            Assert.AreEqual(expectedErrorMessage, orderWithError.ElementAt(1).ValidationErrors[nameof(Order.Quantity)].First());
        }

        [TestCase(0)]
        [Test]
        public void ValidateOrdersAndChangeStatus_InvalidPrice_HasError(decimal invalidPrice)
        {
            //Arrange
            orders.Add(new Order { InstrumentCode = "E2001", Price = invalidPrice, Quantity = validQuantity, Status = OrderStatus.New });

            //Act
            orderService.ValidateOrdersAndChangeStatus(orders);
            var orderWithError = orders.Where(x => x.HasErrors);

            //Assert
            Assert.AreEqual(1, orderWithError.Count());
            Assert.AreEqual(OrderStatus.New, orderWithError.First().Status);
            Assert.AreEqual(invalidPrice, orderWithError.First().Price);
            Assert.AreEqual(1, orderWithError.First().ValidationErrors.Count);
            Assert.AreEqual(invalidPriceErrorMessage, orderWithError.First().ValidationErrors[nameof(Order.Price)].First());
        }

        [TestCase(0, 100001)]
        [Test]
        public void ValidateOrdersAndChangeStatus_InvalidPriceAndInvalidLotSize_HasError(decimal invalidPrice, int invalidLotSize)
        {
            //Arrange
            orders.Add(new Order { InstrumentCode = "E2002", Price = invalidPrice, Quantity = invalidLotSize, Status = OrderStatus.New });
            var expectedErrorMessage = string.Format(invalidLotSizeErrorMessage, "E2002");

            //Act
            orderService.ValidateOrdersAndChangeStatus(orders);
            var orderWithError = orders.Where(x => x.HasErrors);

            //Assert
            Assert.AreEqual(1, orderWithError.Count());
            Assert.AreEqual(OrderStatus.New, orderWithError.First().Status);
            Assert.AreEqual(invalidPrice, orderWithError.First().Price);
            Assert.AreEqual(invalidLotSize, orderWithError.First().Quantity);
            Assert.AreEqual(2, orderWithError.First().ValidationErrors.Count);
            Assert.AreEqual(invalidPriceErrorMessage, orderWithError.First().ValidationErrors[nameof(Order.Price)].First());
            Assert.AreEqual(expectedErrorMessage, orderWithError.First().ValidationErrors[nameof(Order.Quantity)].First());
        }

        [TestCase(0, 0)]
        [TestCase(-23, 0)]
        [Test]
        public void ValidateOrdersAndChangeStatus_InvalidPriceAndInvalidQuantity_HasError(decimal invalidPrice, int invalidLotSize)
        {
            //Arrange
            orders.Add(new Order { InstrumentCode = "E2001", Price = invalidPrice, Quantity = invalidLotSize, Status = OrderStatus.New });

            //Act
            orderService.ValidateOrdersAndChangeStatus(orders);
            var orderWithError = orders.Where(x => x.HasErrors);

            //Assert
            Assert.AreEqual(1, orderWithError.Count());
            Assert.AreEqual(OrderStatus.New, orderWithError.First().Status);
            Assert.AreEqual(invalidPrice, orderWithError.First().Price);
            Assert.AreEqual(invalidLotSize, orderWithError.First().Quantity);
            Assert.AreEqual(2, orderWithError.First().ValidationErrors.Count);
            Assert.AreEqual(invalidPriceErrorMessage, orderWithError.First().ValidationErrors[nameof(Order.Price)].First());
            Assert.AreEqual(invalidQuantityErrorMessage, orderWithError.First().ValidationErrors[nameof(Order.Quantity)].First());
        }

        [Test]
        public void ValidateOrdersAndChangeStatus_ValidLotSizeValidPrice_NoError()
        {
            //Act
            orderService.ValidateOrdersAndChangeStatus(orders);
            var orderWithError = orders.Where(x => x.HasErrors);

            //Assert
            Assert.AreEqual(0, orderWithError.Count());
            Assert.AreEqual(OrderStatus.Submitted, orders.ElementAt(0).Status);
            Assert.AreEqual(OrderStatus.Submitted, orders.ElementAt(1).Status);
        }
    }
}
